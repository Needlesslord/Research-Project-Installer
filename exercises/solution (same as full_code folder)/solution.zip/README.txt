# The game: Pong

This Pong game was created in order to have a game to create an Installer from. 

# How to play:

You need two players, each one will be controlling one bar. 
After each round a point will be added to the respective player who scored. 
The gamem is infinite so you can play for as long as you want to.

# Controls:

W/S to move up/down the player 1 (left)
UP/DOWN ARROWS to move up/down the player 2 right

# License

Copyright @ Needlesslord (Núria Lamonja i Pujol)
This game was created for educational purposes only under a MIT License. Credits for the idea to the respective owners.